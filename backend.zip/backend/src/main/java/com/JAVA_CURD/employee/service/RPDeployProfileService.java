package com.JAVA_CURD.employee.service;

import com.JAVA_CURD.employee.model.RPDeployProfileModel;
import com.JAVA_CURD.employee.model.RPDeployProfileModel.DemandPriority;

import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.time.LocalDate;

@Service
public class RPDeployProfileService {

    private final EntityManager entityManager;

    public RPDeployProfileService(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Transactional
    public void insertDeployProfile(RPDeployProfileModel model) {
        try {
            System.out.println("Received DeployProfileModel: " + model);

            // Build deployRule as comma-separated values
            String deployRule = (model.getSelectedRuleIds() != null)
                    ? String.join(",", model.getSelectedRuleIds().stream().map(String::valueOf).toArray(String[]::new))
                    : "";

            String dmdPtyConfig = model.getDmdPtyConfig();

            // Generate next deployProfileId
            String latestIdSql = "SELECT deployprofileid FROM sclrp.rp_deploy_profile " +
                    "WHERE deployprofileid LIKE 'DEPLOY%' ORDER BY deployprofileid DESC LIMIT 1";

            String latestId = null;
            try {
                latestId = (String) entityManager.createNativeQuery(latestIdSql).getSingleResult();
            } catch (Exception ignored) {
            }

            int nextNumber = 1;
            if (latestId != null && latestId.startsWith("DEPLOY")) {
                try {
                    nextNumber = Integer.parseInt(latestId.substring(6)) + 1;
                } catch (NumberFormatException e) {
                    System.out.println("Failed to parse deployprofileid: " + latestId);
                }
            }
            String newDeployProfileId = "DEPLOY" + nextNumber;

            // Insert into RP_DEPLOY_PROFILE
            String insertProfileSql = "INSERT INTO sclrp.rp_deploy_profile " +
                    "(deployrule, dmd_pty_config, priority_dur, deployprofileid) " +
                    "VALUES (:deployRule, :dmdPtyConfig, :priorityDur, :deployProfileId)";

            entityManager.createNativeQuery(insertProfileSql)
                    .setParameter("deployRule", deployRule)
                    .setParameter("dmdPtyConfig", dmdPtyConfig)
                    .setParameter("priorityDur", model.getPriorityDur())
                    .setParameter("deployProfileId", newDeployProfileId)
                    .executeUpdate();

            System.out.println("Inserted into sclrp.rp_deploy_profile: " + newDeployProfileId);

            // Insert demand priorities
            if (model.getDemandPriorities() != null && !model.getDemandPriorities().isEmpty()) {
                String configSql = "INSERT INTO sclrp.rp_dmd_pty_config " +
                        "(dmd_pty_config, dmd_type, channel, pty) " +
                        "VALUES (:dmdPtyConfig, :dmdType, :channel, :pty)";

                for (DemandPriority dp : model.getDemandPriorities()) {
                    if (dp.getChannel() != null) {
                        entityManager.createNativeQuery(configSql)
                                .setParameter("dmdPtyConfig", dmdPtyConfig)
                                .setParameter("dmdType", dp.getDmdType())
                                .setParameter("channel", dp.getChannel())
                                .setParameter("pty", dp.getPty())
                                .executeUpdate();
                    } else {
                        System.out.println("Skipped insert for dmdType " + dp.getDmdType() + " due to null channel");
                    }
                }
            }

            // Priority_Dur logic: calculate end date from RP_SKU_REPLEN_PARAM.plan_date
            String planDateSql = "SELECT plan_date FROM sclrp.rp_sku_replen_param WHERE deployprofileid = :deployProfileId LIMIT 1";
            Date planDate = null;
            try {
                planDate = (Date) entityManager.createNativeQuery(planDateSql)
                        .setParameter("deployProfileId", newDeployProfileId)
                        .getSingleResult();
            } catch (Exception e) {
                System.out.println("No plan_date found for deployProfileId: " + newDeployProfileId);
            }

            if (planDate != null) {
                LocalDate startDate = planDate.toLocalDate();
                LocalDate endDate = startDate.plusDays(model.getPriorityDur());
                System.out.println("Priority Duration starts on " + startDate + " and ends on " + endDate);
            } else {
                System.out.println("Cannot calculate end date: plan_date not found for " + newDeployProfileId);
            }

            System.out.println("Deploy profile and demand priorities inserted successfully.");

        } catch (Exception e) {
            System.out.println("Error inserting deploy rule: " + e.getMessage());
            throw new RuntimeException("Failed to insert deploy rule.", e);
        }
    }
}
