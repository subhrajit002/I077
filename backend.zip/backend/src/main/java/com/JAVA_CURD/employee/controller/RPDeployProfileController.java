package com.JAVA_CURD.employee.controller;


import com.JAVA_CURD.employee.model.RPDeployProfileModel;
import com.JAVA_CURD.employee.service.RPDeployProfileService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/deploy")
public class RPDeployProfileController {

    @Autowired
    private RPDeployProfileService service;

    @PostMapping("/add")
    public ResponseEntity<String> insertDeployProfile(@RequestBody RPDeployProfileModel model) {
        service.insertDeployProfile(model);
        return ResponseEntity.ok("Deploy profile saved successfully!");
    }
}
