package com.JAVA_CURD.employee.service;

import java.util.List;

import org.springframework.boot.autoconfigure.batch.BatchProperties.Jdbc;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.JAVA_CURD.employee.entity.EmployeeDB;
import com.JAVA_CURD.employee.repository.EmployeeRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EmployeeService {

    // this is for the connection or talking with db
    private final EmployeeRepository employeeRepository;

    // saving the employee in DB
    public EmployeeDB savEmployeeDB(EmployeeDB employee) {
        return employeeRepository.save(employee);
    }

    // public List<EmployeeDB> getEmployees(){
    // return employeeRepository.findAll();
    // }

    private final JdbcTemplate jdbcTemplate;

    public List<EmployeeDB> getallEmployees() {
        String sql = "SELECT * FROM employeedb";
        return jdbcTemplate.query(sql, (rs, rowNum) -> {
            EmployeeDB emp = new EmployeeDB();
            emp.setId(rs.getLong("id"));
            emp.setName(rs.getString("name"));
            emp.setEmail(rs.getString("email"));
            emp.setPhone(rs.getString("phone"));
            emp.setDepartment(rs.getString("department"));
            return emp;
        });
    }

    public int updateEmployee(EmployeeDB emp) {
        String sql = "UPDATE employeedb " +
                "SET name = ?, email = ?, phone = ?, department = ? " +
                "WHERE id = ?";

        return jdbcTemplate.update(
                sql,
                emp.getName(),
                emp.getEmail(),
                emp.getPhone(),
                emp.getDepartment(),
                emp.getId());
    }

}
