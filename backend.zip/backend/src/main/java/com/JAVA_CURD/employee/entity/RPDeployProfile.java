package com.JAVA_CURD.employee.entity;


import jakarta.persistence.*;

@Entity
@Table(name = "rp_deploy_profile", schema = "sclrp")
public class RPDeployProfile {

    @Id
    @Column(name = "deployprofileid")
    private String deployProfileId;

    @Column(name = "deployrule")
    private String deployRule;

    @Column(name = "priority_dur")
    private int priorityDur;

    @Column(name = "dmd_pty_config")
    private String dmdPtyConfig;

    public RPDeployProfile() {}

    public String getDeployProfileId() {
        return deployProfileId;
    }

    public void setDeployProfileId(String deployProfileId) {
        this.deployProfileId = deployProfileId;
    }

    public String getDeployRule() {
        return deployRule;
    }

    public void setDeployRule(String deployRule) {
        this.deployRule = deployRule;
    }

    public int getPriorityDur() {
        return priorityDur;
    }

    public void setPriorityDur(int priorityDur) {
        this.priorityDur = priorityDur;
    }

    public String getDmdPtyConfig() {
        return dmdPtyConfig;
    }

    public void setDmdPtyConfig(String dmdPtyConfig) {
        this.dmdPtyConfig = dmdPtyConfig;
    }
}

