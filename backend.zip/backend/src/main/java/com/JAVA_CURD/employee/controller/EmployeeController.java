package com.JAVA_CURD.employee.controller;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.JAVA_CURD.employee.entity.EmployeeDB;
import com.JAVA_CURD.employee.service.EmployeeService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@CrossOrigin("*")

public class EmployeeController {

    private final EmployeeService employeeService;

    // sb smy db class k call koro r okhane save koro
    @PostMapping("/employee")
    public EmployeeDB postEmployee(@RequestBody EmployeeDB employee) {
        return employeeService.savEmployeeDB(employee);
    }

    // get all employees
    @GetMapping("/allemployees")
    public List<EmployeeDB> getAllEmployees() {
        return employeeService.getallEmployees();
    }

    // update the employee
    @PutMapping("/update/{id}")
    public String updateEmp(@PathVariable Long id, @RequestBody EmployeeDB emp) {
        emp.setId(id);
        int rows = employeeService.updateEmployee(emp);
        return rows > 0 ? "Employee updated successfully" : "Employee not found";
    }

   

}
