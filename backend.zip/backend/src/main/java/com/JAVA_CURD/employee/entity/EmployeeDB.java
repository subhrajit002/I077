package com.JAVA_CURD.employee.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data

public class EmployeeDB {

    @Id // to make the id as primary key we are doing @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // increamentatino of id
    private Long id;

    private String name;
    private String email;

    private String phone;

    private String department;
}
