import './App.css';
import Dashboard from './pages/dashboard/Dashboard';
import Header from './pages/Header/Header';
import { Route, Routes } from 'react-router-dom'
import NoMatch from './pages/noMatch/NoMatch';
import AddUser from './pages/employee/AddUser';

function App() {
  return (
    <>
      <Header />
      <Routes>
        <Route path='/' element={<Dashboard />} />
        <Route path='*' element={<NoMatch />} />
        <Route path='/employee' element={<AddUser />} />
        
      </Routes>
    </>
  );
}

export default App;
