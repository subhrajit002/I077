import React, { useEffect, useState } from 'react'

const Dashboard = () => {
    const [employees, setEmployees] = useState([])

    useEffect(() => {
        const fetchEmployees = async () => {
            try {
                const response = await fetch("http://localhost:8080/api/allemployees");
                const data = await response.json()
                console.log(data)
                setEmployees(data);
            } catch (error) {
                console.log("error while getting employees ", error.message)
            }
        }
        fetchEmployees();
    }, [])
    return (
        <>
            <table className="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Phone</th>
                        <th scope="col">Department</th>
                    </tr>
                </thead>
                <tbody>
                    {employees?.map((employees, index) => (
                        <tr key={index} >
                            <td>{employees.id}</td>
                            <td>{employees.name}</td>
                            <td>{employees.email}</td>
                            <td> {employees.phone}</td>
                            <td>{employees.department}</td>
                            <td>
                                <button type="button" className="btn btn-secondary">Edit</button>
                                <button type="button" className="btn btn-secondary mx-2">Delete</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </>
    )
}

export default Dashboard
