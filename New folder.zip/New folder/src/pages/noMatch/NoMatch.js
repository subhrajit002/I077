import React from 'react'

const NoMatch = () => {
    return (
        <div>
            PAGE NOT FOUND 404
        </div>
    )
}

export default NoMatch
