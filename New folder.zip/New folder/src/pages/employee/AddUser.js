import { useState } from 'react'
import { useNavigate } from 'react-router-dom';

const AddUser = () => {

    const [formData, setFormdata] = useState({
        name: "",
        email: "",
        phone: "",
        department: ""
    })

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormdata({
            ...formData,
            [name]: value
        })
    }

    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const res = await fetch("http://localhost:8080/api/employee", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(formData)
            })

            const data = await res.json();
            console.log("data send", data)
            navigate("/");
        } catch (error) {
            console.log("error: ", error.message)
            throw new Error(error)
        }
    }

    return (
        <form onSubmit={handleSubmit}>
            <div className="mb-3 container-fluid">
                <input
                    type="text"
                    className="form-control"
                    id="exampleFormControlInput1"
                    onChange={handleInputChange}
                    name='name'
                    value={formData.name}
                    placeholder='subhrajit'
                />
                <input
                    type="email"
                    className="form-control my-4"
                    id="exampleFormControlInput1"
                    placeholder="name@example.com"
                    onChange={handleInputChange}
                    name='email'
                    value={formData.email}
                />
                <input
                    type="number"
                    className="form-control"
                    id="exampleFormControlInput1"
                    placeholder="9635877303"
                    onChange={handleInputChange}
                    name='phone'
                    value={formData.phone}
                />
                <input
                    type="text"
                    className="form-control my-4"
                    id="exampleFormControlInput1"
                    placeholder="department"
                    onChange={handleInputChange}
                    name='department'
                    value={formData.department}
                />
            </div>
            <div className="col-auto">
                <button type="submit" className="btn btn-primary mb-3">Confirm identity</button>
            </div>
        </form>
    )
}

export default AddUser
