import React from "react";
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    Tooltip,
    Legend,
    CartesianGrid,
    ResponsiveContainer,
    PieChart,
    Pie,
    Cell,
} from "recharts";
import "bootstrap/dist/css/bootstrap.min.css";

const DashboardSection = () => {
    // Mock Data
    const projectBudgetData = [
        { name: "IT", green: 27.9, red: 23.3 },
        { name: "Faculty", green: 13.8, amber: 2.8 },
        { name: "HR", green: 4.0 },
        { name: "Estates", red: 3.3 },
        { name: "Finance", red: 2.5, green: 1.5 },
    ];

    const portfolioBalanceData = [
        { name: "Cost Avoidance", value: 10.2 },
        { name: "Cost Reduction", value: 12.2 },
        { name: "Growth", value: 21.9 },
        { name: "Sustaining", value: 24.9 },
        { name: "Maintaining", value: 28.3 },
    ];

    const approvedBudgetData = [
        { quarter: "Q1", value: 13.5 },
        { quarter: "Q2", value: 14.9 },
        { quarter: "Q3", value: 19.4 },
        { quarter: "Q4", value: 27.9 },
        { quarter: "Total", value: 57.7 },
    ];

    const pieColors = ["#8a2be2", "#9932cc", "#ff8c00", "#1e90ff", "#4169e1"];

    return (
        <div className="container-fluid bg-white p-3 rounded shadow-sm">
            <div className="row">
                {/* STATUS PANEL AND PROJECT BUDGET */}
                <div className="col-5 border-right">
                    <div
                        className="row d-flex align-items-stretch"
                        style={{ height: "250px" }}
                    >
                        {/* STATUS SECTION */}
                        <div className="col-3 d-flex flex-column justify-content-between">
                            <div className="flex-grow-1">
                                <h6 className="font-weight-bold text-center">Status</h6>
                                <div className="d-flex justify-content-between">
                                    <span>Demand</span>{" "}
                                    <span className="font-weight-bold">14</span>
                                </div>
                                <div className="d-flex justify-content-between">
                                    <span>Active</span>{" "}
                                    <span className="font-weight-bold">35</span>
                                </div>
                                <hr />
                                <div className="d-flex justify-content-between">
                                    <span>Total</span>{" "}
                                    <span className="font-weight-bold">49</span>
                                </div>
                            </div>

                            <div>
                                <div className="d-flex justify-content-between mb-2  bg-danger text-white rounded">
                                    <strong>Red</strong>
                                    <div>12</div>
                                </div>
                                <div className="d-flex justify-content-between mb-2  bg-warning rounded">
                                    <strong>Amber</strong>
                                    <div>6</div>
                                </div>
                                <div className="d-flex justify-content-between  bg-success text-white rounded">
                                    <strong>Green</strong>
                                    <div>31</div>
                                </div>
                            </div>
                        </div>

                        {/* PROJECT BUDGET SECTION */}
                        <div className="col-9 d-flex flex-column">
                            <h6 className="font-weight-bold text-center mb-2">
                                Project Budget by Funding Entity
                            </h6>
                            <div className="flex-grow-1">
                                <ResponsiveContainer width="100%" height="100%">
                                    <BarChart
                                        data={projectBudgetData}
                                        layout="vertical"
                                        margin={{ top: 10, right: 30, left: 20, bottom: 5 }}
                                    >
                                        <CartesianGrid strokeDasharray="3 3" />
                                        <XAxis type="number" tickFormatter={(v) => `£${v}M`} />
                                        <YAxis type="category" dataKey="name" />
                                        <Tooltip formatter={(v) => `£${v}M`} />
                                        <Legend />
                                        <Bar dataKey="green" stackId="a" fill="#00C49F" />
                                        <Bar dataKey="amber" stackId="a" fill="#FFBB28" />
                                        <Bar dataKey="red" stackId="a" fill="#FF4D4F" />
                                    </BarChart>
                                </ResponsiveContainer>
                            </div>
                        </div>
                    </div>

                    {/* PORTFOLIO & APPROVED BUDGET ROW */}
                    <div className="row mt-3">
                        <div className="col-6">
                            <h6 className="font-weight-bold text-center mb-2">
                                Portfolio Balance
                            </h6>
                            <ResponsiveContainer width="100%" height={200}>
                                <PieChart>
                                    <Pie
                                        data={portfolioBalanceData}
                                        dataKey="value"
                                        nameKey="name"
                                        outerRadius={70}
                                        label
                                    >
                                        {portfolioBalanceData.map((entry, index) => (
                                            <Cell
                                                key={`cell-${index}`}
                                                fill={pieColors[index % pieColors.length]}
                                            />
                                        ))}
                                    </Pie>
                                    <Tooltip />
                                </PieChart>
                            </ResponsiveContainer>
                        </div>

                        <div className="col-6">
                            <h6 className="font-weight-bold text-center mb-2">
                                Approved Budget by Quarter
                            </h6>
                            <ResponsiveContainer width="100%" height={200}>
                                <BarChart
                                    data={approvedBudgetData}
                                    margin={{ top: 10, right: 30, left: 0, bottom: 5 }}
                                >
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="quarter" />
                                    <YAxis tickFormatter={(v) => `£${v}M`} />
                                    <Tooltip formatter={(v) => `£${v}M`} />
                                    <Bar dataKey="value">
                                        {approvedBudgetData.map((entry, index) => (
                                            <Cell
                                                key={`cell-${index}`}
                                                fill={index === 4 ? "#1890FF" : "#00C49F"}
                                            />
                                        ))}
                                    </Bar>
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default DashboardSection;
