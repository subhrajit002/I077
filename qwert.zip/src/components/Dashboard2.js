"use client"
import "bootstrap/dist/css/bootstrap.min.css"
import {
    PieChart,
    Pie,
    Cell,
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    Legend,
    ResponsiveContainer,
    AreaChart,
    Area,
    ComposedChart,
} from "recharts"
import "./dashboard2.css"

const ProjectPortfolioDashboard = () => {
    // Portfolio Balance Data
    const portfolioBalanceData = [
        { name: "Cost Avoidance", value: 18.2 },
        { name: "Maintaining", value: 23.3 },
        { name: "Cost Reduction", value: 12.2 },
        { name: "Growth", value: 21.3 },
        { name: "Sustaining", value: 25.0 },
    ]

    const COLORS = ["#8B4789", "#1E3A8A", "#D97706", "#F59E0B", "#10B981"]

    // Approved Budget by Quarter Data
    const quarterlyData = [
        { quarter: "Q1", Estates: 45, Faculty: 32, Finance: 28, HR: 35, IT: 42 },
        { quarter: "Q2", Estates: 52, Faculty: 38, Finance: 35, HR: 40, IT: 48 },
        { quarter: "Q3", Estates: 48, Faculty: 35, Finance: 32, HR: 38, IT: 45 },
        { quarter: "Q4", Estates: 60, Faculty: 42, Finance: 40, HR: 45, IT: 55 },
    ]

    // Portfolio Budgets by Time Data
    const timeSeriesData = [
        { quarter: "Q1", Estates: 45, Faculty: 32, Finance: 28, HR: 35, IT: 42 },
        { quarter: "Q2", Estates: 52, Faculty: 38, Finance: 35, HR: 40, IT: 48 },
        { quarter: "Q3", Estates: 48, Faculty: 35, Finance: 32, HR: 38, IT: 45 },
        { quarter: "Q4", Estates: 60, Faculty: 42, Finance: 40, HR: 45, IT: 55 },
    ]

    // Resource Effort vs Capacity Data
    const resourceData = [
        {
            team: "2019",
            "App Development": 120,
            Architecture: 100,
            "Business Analysis": 80,
            "Cloud Services": 90,
            Desktop: 70,
            "Desktop Mgmt": 60,
            "Identity Management": 50,
            Infrastructure: 85,
            Operations: 75,
            "Project Management": 65,
            Security: 55,
            Testing: 70,
        },
        {
            team: "2020",
            "App Development": 140,
            Architecture: 120,
            "Business Analysis": 100,
            "Cloud Services": 110,
            Desktop: 80,
            "Desktop Mgmt": 70,
            "Identity Management": 60,
            Infrastructure: 100,
            Operations: 90,
            "Project Management": 80,
            Security: 70,
            Testing: 85,
        },
        {
            team: "2021",
            "App Development": 130,
            Architecture: 110,
            "Business Analysis": 95,
            "Cloud Services": 105,
            Desktop: 75,
            "Desktop Mgmt": 65,
            "Identity Management": 55,
            Infrastructure: 95,
            Operations: 85,
            "Project Management": 75,
            Security: 65,
            Testing: 80,
        },
    ]

    // Project List Data
    const projectsData = [
        {
            id: "PR000001",
            title: "New Student Mobile Application",
            status: "Green",
            scope: "Green",
            schedule: "Orange",
            budget: "Green",
            approved: "£462,114",
            actual: "£49,030",
            estimate: "£379,879",
            variance: "£33,205",
        },
        {
            id: "PR000002",
            title: "Research Systems Re-Platform",
            status: "Green",
            scope: "Green",
            schedule: "Green",
            budget: "Green",
            approved: "£767,130",
            actual: "£169,300",
            estimate: "£445,191",
            variance: "£152,839",
        },
        {
            id: "PR000003",
            title: "HR System Replacement",
            status: "Green",
            scope: "Green",
            schedule: "Green",
            budget: "Green",
            approved: "£452,843",
            actual: "£213,919",
            estimate: "£631,747",
            variance: "£-178,253",
        },
        {
            id: "PR000004",
            title: "Student Journey CRM Project",
            status: "Green",
            scope: "Green",
            schedule: "Green",
            budget: "Green",
            approved: "£1,398,345",
            actual: "£1,112,095",
            estimate: "£99,682",
            variance: "£187,068",
        },
        {
            id: "PR000005",
            title: "Learner Analytics",
            status: "Green",
            scope: "Green",
            schedule: "Orange",
            budget: "Green",
            approved: "£335,610",
            actual: "£73,090",
            estimate: "£99,620",
            variance: "£167,100",
        },
        {
            id: "PR000006",
            title: "Business process automation RPA project",
            status: "Green",
            scope: "Green",
            schedule: "Green",
            budget: "Green",
            approved: "£1,872,729",
            actual: "£887,886",
            estimate: "£884,919",
            variance: "£128,113",
        },
        {
            id: "PR000007",
            title: "Tribal SITS Upgrade",
            status: "Green",
            scope: "Green",
            schedule: "Green",
            budget: "Green",
            approved: "£1,582,080",
            actual: "£37,207",
            estimate: "£931,577",
            variance: "£613,296",
        },
        {
            id: "PR000008",
            title: "Digital Assessments Implementation",
            status: "Green",
            scope: "Green",
            schedule: "Green",
            budget: "Green",
            approved: "£1,339,834",
            actual: "£586,185",
            estimate: "£646,673",
            variance: "£306,976",
        },
        {
            id: "PR000009",
            title: "Blended Learning Collaboration platform",
            status: "Green",
            scope: "Green",
            schedule: "Green",
            budget: "Green",
            approved: "£815,493",
            actual: "£618,232",
            estimate: "£292,236",
            variance: "£-95,207",
        },
        {
            id: "PR000010",
            title: "Prep for Clearing 2020",
            status: "Green",
            scope: "Green",
            schedule: "Green",
            budget: "Green",
            approved: "£1,018,251",
            actual: "£42,898",
            estimate: "£646,584",
            variance: "£328,769",
        },
        {
            id: "PR000011",
            title: "Prep for Start of Year 2020",
            status: "Green",
            scope: "Green",
            schedule: "Green",
            budget: "Green",
            approved: "£1,439,536",
            actual: "£404,311",
            estimate: "£581,356",
            variance: "£443,849",
        },
    ]

    const getStatusColor = (status) => {
        switch (status) {
            case "Green":
                return "#10B981"
            case "Orange":
                return "#F59E0B"
            case "Red":
                return "#EF4444"
            default:
                return "#6B7280"
        }
    }

    return (
        <div className="dashboard-container">
            <div className="container-fluid p-4" style={{ backgroundColor: "#f5f5f5", minHeight: "100vh" }}>
                {/* Header */}
                <div className="row mb-4">
                    <div className="col-12">
                        <div className="d-flex align-items-center gap-3 mb-3">
                            <div
                                className="logo-box"
                                style={{ width: "50px", height: "50px", backgroundColor: "#4B5563", borderRadius: "4px" }}
                            ></div>
                            <div>
                                <h1 className="mb-0" style={{ fontSize: "28px", fontWeight: "bold", color: "#333" }}>
                                    MAXICA CONSULTING
                                </h1>
                                <p className="mb-0" style={{ fontSize: "12px", color: "#666" }}>
                                    Business & IT Management Consultancy
                                </p>
                            </div>
                        </div>
                        <h2 style={{ fontSize: "20px", fontWeight: "bold", color: "#333" }}>Project Portfolio Dashboard</h2>
                    </div>
                </div>

                {/* Summary Cards */}
                <div className="row mb-4">
                    <div className="col-md-3">
                        <div className="card p-3" style={{ backgroundColor: "#fff", border: "1px solid #ddd" }}>
                            <div className="card-body p-0">
                                <h6 className="text-muted mb-2">Approved Budget</h6>
                                <h3 style={{ color: "#1E3A8A", fontWeight: "bold" }}>£56.59M</h3>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-3">
                        <div className="card p-3" style={{ backgroundColor: "#fff", border: "1px solid #ddd" }}>
                            <div className="card-body p-0">
                                <h6 className="text-muted mb-2">Actual Cost</h6>
                                <h3 style={{ color: "#1E3A8A", fontWeight: "bold" }}>£15.89M</h3>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-3">
                        <div className="card p-3" style={{ backgroundColor: "#fff", border: "1px solid #ddd" }}>
                            <div className="card-body p-0">
                                <h6 className="text-muted mb-2">Estimate to Complete</h6>
                                <h3 style={{ color: "#1E3A8A", fontWeight: "bold" }}>£17.41M</h3>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-3">
                        <div className="card p-3" style={{ backgroundColor: "#fff", border: "1px solid #ddd" }}>
                            <div className="card-body p-0">
                                <h6 className="text-muted mb-2">Variance</h6>
                                <h3 style={{ color: "#10B981", fontWeight: "bold" }}>£8.81M</h3>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Main Content */}
                <div className="row mb-4">
                    {/* Left Sidebar */}
                    <div className="col-md-3">
                        {/* Status Summary */}
                        <div className="card mb-3" style={{ backgroundColor: "#fff", border: "1px solid #ddd" }}>
                            <div className="card-header" style={{ backgroundColor: "#f8f9fa", borderBottom: "1px solid #ddd" }}>
                                <h6 className="mb-0" style={{ fontWeight: "bold" }}>
                                    Status
                                </h6>
                            </div>
                            <div className="card-body p-3">
                                <div className="mb-2 d-flex justify-content-between">
                                    <span>Active</span>
                                    <span style={{ fontWeight: "bold" }}>35</span>
                                </div>
                                <div className="mb-2 d-flex justify-content-between">
                                    <span>Inactive</span>
                                    <span style={{ fontWeight: "bold" }}>5</span>
                                </div>
                                <div className="d-flex justify-content-between">
                                    <span>Total</span>
                                    <span style={{ fontWeight: "bold" }}>40</span>
                                </div>
                            </div>
                        </div>

                        {/* Status Legend */}
                        <div className="card mb-3" style={{ backgroundColor: "#fff", border: "1px solid #ddd" }}>
                            <div className="card-header" style={{ backgroundColor: "#f8f9fa", borderBottom: "1px solid #ddd" }}>
                                <h6 className="mb-0" style={{ fontWeight: "bold" }}>
                                    Status Legend
                                </h6>
                            </div>
                            <div className="card-body p-3">
                                <div className="mb-2 d-flex align-items-center gap-2">
                                    <div style={{ width: "20px", height: "20px", backgroundColor: "#EF4444", borderRadius: "3px" }}></div>
                                    <span>Red</span>
                                    <span style={{ marginLeft: "auto", fontWeight: "bold" }}>12</span>
                                </div>
                                <div className="mb-2 d-flex align-items-center gap-2">
                                    <div style={{ width: "20px", height: "20px", backgroundColor: "#F59E0B", borderRadius: "3px" }}></div>
                                    <span>Amber</span>
                                    <span style={{ marginLeft: "auto", fontWeight: "bold" }}>6</span>
                                </div>
                                <div className="d-flex align-items-center gap-2">
                                    <div style={{ width: "20px", height: "20px", backgroundColor: "#10B981", borderRadius: "3px" }}></div>
                                    <span>Green</span>
                                    <span style={{ marginLeft: "auto", fontWeight: "bold" }}>31</span>
                                </div>
                            </div>
                        </div>

                        {/* Portfolio Balance Pie Chart */}
                        <div className="card mb-3" style={{ backgroundColor: "#fff", border: "1px solid #ddd" }}>
                            <div className="card-header" style={{ backgroundColor: "#f8f9fa", borderBottom: "1px solid #ddd" }}>
                                <h6 className="mb-0" style={{ fontWeight: "bold" }}>
                                    Portfolio Balance
                                </h6>
                            </div>
                            <div className="card-body p-3">
                                <ResponsiveContainer width="100%" height={200}>
                                    <PieChart>
                                        <Pie
                                            data={portfolioBalanceData}
                                            cx="50%"
                                            cy="50%"
                                            innerRadius={40}
                                            outerRadius={80}
                                            paddingAngle={2}
                                            dataKey="value"
                                        >
                                            {portfolioBalanceData.map((entry, index) => (
                                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                            ))}
                                        </Pie>
                                    </PieChart>
                                </ResponsiveContainer>
                                <div style={{ fontSize: "11px", marginTop: "10px" }}>
                                    {portfolioBalanceData.map((item, idx) => (
                                        <div key={idx} className="d-flex justify-content-between mb-1">
                                            <span>{item.name}</span>
                                            <span style={{ fontWeight: "bold" }}>{item.value}%</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>

                        {/* Approved Budget by Quarter */}
                        <div className="card mb-3" style={{ backgroundColor: "#fff", border: "1px solid #ddd" }}>
                            <div className="card-header" style={{ backgroundColor: "#f8f9fa", borderBottom: "1px solid #ddd" }}>
                                <h6 className="mb-0" style={{ fontWeight: "bold" }}>
                                    Approved Budget by Quarter
                                </h6>
                            </div>
                            <div className="card-body p-3">
                                <ResponsiveContainer width="100%" height={250}>
                                    <BarChart data={quarterlyData}>
                                        <CartesianGrid strokeDasharray="3 3" />
                                        <XAxis dataKey="quarter" />
                                        <YAxis />
                                        <Tooltip />
                                        <Bar dataKey="Estates" fill="#10B981" />
                                        <Bar dataKey="Faculty" fill="#F59E0B" />
                                        <Bar dataKey="Finance" fill="#1E3A8A" />
                                        <Bar dataKey="HR" fill="#8B4789" />
                                        <Bar dataKey="IT" fill="#D97706" />
                                    </BarChart>
                                </ResponsiveContainer>
                            </div>
                        </div>

                        {/* Portfolio Budgets by Time */}
                        <div className="card" style={{ backgroundColor: "#fff", border: "1px solid #ddd" }}>
                            <div className="card-header" style={{ backgroundColor: "#f8f9fa", borderBottom: "1px solid #ddd" }}>
                                <h6 className="mb-0" style={{ fontWeight: "bold" }}>
                                    Portfolio Budgets by Time
                                </h6>
                            </div>
                            <div className="card-body p-3">
                                <ResponsiveContainer width="100%" height={250}>
                                    <AreaChart data={timeSeriesData}>
                                        <CartesianGrid strokeDasharray="3 3" />
                                        <XAxis dataKey="quarter" />
                                        <YAxis />
                                        <Tooltip />
                                        <Legend />
                                        <Area type="monotone" dataKey="Estates" stackId="1" stroke="#10B981" fill="#10B981" />
                                        <Area type="monotone" dataKey="Faculty" stackId="1" stroke="#F59E0B" fill="#F59E0B" />
                                        <Area type="monotone" dataKey="Finance" stackId="1" stroke="#1E3A8A" fill="#1E3A8A" />
                                        <Area type="monotone" dataKey="HR" stackId="1" stroke="#8B4789" fill="#8B4789" />
                                        <Area type="monotone" dataKey="IT" stackId="1" stroke="#D97706" fill="#D97706" />
                                    </AreaChart>
                                </ResponsiveContainer>
                            </div>
                        </div>
                    </div>

                    {/* Right Content */}
                    <div className="col-md-9">
                        {/* Projects Table */}
                        <div className="card mb-4" style={{ backgroundColor: "#fff", border: "1px solid #ddd" }}>
                            <div className="card-header" style={{ backgroundColor: "#f8f9fa", borderBottom: "1px solid #ddd" }}>
                                <h6 className="mb-0" style={{ fontWeight: "bold" }}>
                                    Project List
                                </h6>
                            </div>
                            <div className="card-body p-0">
                                <div style={{ overflowX: "auto" }}>
                                    <table className="table table-sm mb-0" style={{ fontSize: "12px" }}>
                                        <thead style={{ backgroundColor: "#1E3A8A", color: "#fff" }}>
                                            <tr>
                                                <th>Project Code</th>
                                                <th>Project Title</th>
                                                <th>Overall Status</th>
                                                <th>Scope Status</th>
                                                <th>Schedule Status</th>
                                                <th>Budget Status</th>
                                                <th>Approved Budget</th>
                                                <th>Actual Cost</th>
                                                <th>Estimate to Complete</th>
                                                <th>Variance</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {projectsData.map((project, idx) => (
                                                <tr key={idx}>
                                                    <td>{project.id}</td>
                                                    <td>{project.title}</td>
                                                    <td>
                                                        <div
                                                            style={{
                                                                width: "20px",
                                                                height: "20px",
                                                                backgroundColor: getStatusColor(project.status),
                                                                borderRadius: "3px",
                                                            }}
                                                        ></div>
                                                    </td>
                                                    <td>
                                                        <div
                                                            style={{
                                                                width: "20px",
                                                                height: "20px",
                                                                backgroundColor: getStatusColor(project.scope),
                                                                borderRadius: "3px",
                                                            }}
                                                        ></div>
                                                    </td>
                                                    <td>
                                                        <div
                                                            style={{
                                                                width: "20px",
                                                                height: "20px",
                                                                backgroundColor: getStatusColor(project.schedule),
                                                                borderRadius: "3px",
                                                            }}
                                                        ></div>
                                                    </td>
                                                    <td>
                                                        <div
                                                            style={{
                                                                width: "20px",
                                                                height: "20px",
                                                                backgroundColor: getStatusColor(project.budget),
                                                                borderRadius: "3px",
                                                            }}
                                                        ></div>
                                                    </td>
                                                    <td>{project.approved}</td>
                                                    <td>{project.actual}</td>
                                                    <td>{project.estimate}</td>
                                                    <td>{project.variance}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        {/* Resource Effort vs Capacity */}
                        <div className="card" style={{ backgroundColor: "#fff", border: "1px solid #ddd" }}>
                            <div className="card-header" style={{ backgroundColor: "#f8f9fa", borderBottom: "1px solid #ddd" }}>
                                <h6 className="mb-0" style={{ fontWeight: "bold" }}>
                                    Resource Effort vs Capacity by Team (hours)
                                </h6>
                            </div>
                            <div className="card-body p-3">
                                <ResponsiveContainer width="100%" height={350}>
                                    <ComposedChart data={resourceData} layout="vertical">
                                        <CartesianGrid strokeDasharray="3 3" />
                                        <XAxis type="number" />
                                        <YAxis dataKey="team" type="category" />
                                        <Tooltip />
                                        <Legend />
                                        <Bar dataKey="App Development" fill="#1E3A8A" />
                                        <Bar dataKey="Architecture" fill="#1E40AF" />
                                        <Bar dataKey="Business Analysis" fill="#DC2626" />
                                        <Bar dataKey="Cloud Services" fill="#EA580C" />
                                        <Bar dataKey="Desktop" fill="#F59E0B" />
                                        <Bar dataKey="Desktop Mgmt" fill="#FBBF24" />
                                        <Bar dataKey="Identity Management" fill="#A78BFA" />
                                        <Bar dataKey="Infrastructure" fill="#60A5FA" />
                                        <Bar dataKey="Operations" fill="#34D399" />
                                        <Bar dataKey="Project Management" fill="#10B981" />
                                        <Bar dataKey="Security" fill="#06B6D4" />
                                        <Bar dataKey="Testing" fill="#8B5CF6" />
                                    </ComposedChart>
                                </ResponsiveContainer>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default ProjectPortfolioDashboard
