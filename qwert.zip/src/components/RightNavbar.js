import React from "react";
import { Link } from "react-router-dom";

const RightNavbar = () => {
  return (
    <div
      className="d-flex flex-column bg-dark text-white position-fixed top-0 end-0 vh-100 p-3"
      style={{ width: "220px", marginTop: "60px" }}
    >
      <h5 className="text-center mb-4">Menu</h5>
      <ul className="nav flex-column text-end">
        <li className="nav-item">
          <Link to="/" className="nav-link text-white">
            Home
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/about" className="nav-link text-white">
            About
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/services" className="nav-link text-white">
            Services
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/contact" className="nav-link text-white">
            Contact
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default RightNavbar;
