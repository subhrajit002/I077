import React from "react";

const Header = () => {
  return (
    <header className="bg-dark text-white text-center py-3 fixed-top w-100">
      <h4 className="m-0">Welcome Subhrajit</h4>
    </header>
  );
};

export default Header;
