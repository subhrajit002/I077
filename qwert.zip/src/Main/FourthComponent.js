import React, { useState } from "react";
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    Tooltip,
    ResponsiveContainer,
} from "recharts";

const FourthComponent = () => {
    const data = [
        { name: "2024", "Product Development": 4000, "Customer Success": 2400, "PMG": 2400 },
        { name: "2023", "Product Development": 3000, "Customer Success": 1398, "PMG": 2210 },
        { name: "2022", "Product Development": 2000, "Customer Success": 9800, "PMG": 2290 },
    ];

    const [visibleBars, setVisibleBars] = useState({
        "Product Development": true,
        "Customer Success": true,
        "PMG": true,
    });

    const handleLegendClick = (key) => {
        setVisibleBars((prev) => ({
            ...prev,
            [key]: !prev[key],
        }));
    };

    const legendItems = [
        { key: "Product Development", label: "Product Development", color: "#8884d8" },
        { key: "Customer Success", label: "Customer Success", color: "#82ca9d" },
        { key: "PMG", label: "PMG", color: "#c15b98" },
    ];

    return (
        <div className="row justify-content-center" style={{ margin: "20px 0" }}>
            <div className="col-md-6">
                <div
                    className="card"
                    style={{
                        height: "280px",
                        backgroundColor: "#fff",
                        border: "1px solid #ddd",
                        borderRadius: "12px",
                        boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
                        padding: "10px",
                    }}
                >
                    <h6 className="font-weight-bold text-center mt-2 mb-2 text-muted">
                        Resource Effort vs Capacity by Teams (hours)
                    </h6>
                    <div style={{ width: "100%", height: "180px" }}>
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart
                                data={data}
                                margin={{ top: 10, right: 20, left: 0, bottom: 20 }}
                            >
                                <XAxis
                                    dataKey="name"
                                    axisLine={false}
                                    style={{ fontSize: "10px" }}
                                />
                                <YAxis
                                    axisLine={false}
                                    style={{ fontSize: "10px" }}
                                />
                                <Tooltip
                                    contentStyle={{ fontSize: "10px" }}
                                    itemStyle={{ fontSize: "10px" }}
                                    cursor={{ fill: "transparent" }}
                                />
                                {visibleBars["Product Development"] && (
                                    <Bar dataKey="Product Development" fill="#8884d8" barSize={25} stackId="a" />
                                )}
                                {visibleBars["Customer Success"] && (
                                    <Bar dataKey="Customer Success" fill="#82ca9d" barSize={25} stackId="a" />
                                )}
                                {visibleBars["PMG"] && (
                                    <Bar dataKey="PMG" fill="#c15b98" barSize={25} stackId="a" />
                                )}
                            </BarChart>
                        </ResponsiveContainer>
                        <div style={{ display: "flex", justifyContent: "center", gap: "1rem", fontSize: "11px", paddingBottom: "10px" }}>
                            {legendItems.map(({ key, label, color }) => (
                                <span
                                    key={key}
                                    onClick={() => handleLegendClick(key)}
                                    style={{
                                        cursor: "pointer",
                                        color: visibleBars[key] ? color : "#ccc",
                                        textDecoration: visibleBars[key] ? "none" : "line-through",
                                        fontWeight: visibleBars[key] ? "bold" : "normal",
                                    }}
                                >
                                    ● {label}
                                </span>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};


export default FourthComponent
