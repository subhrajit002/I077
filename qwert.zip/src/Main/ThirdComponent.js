import { useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

const ThirdComponent = () => {
    const data = [
        { name: 'QTR 1', estates: 4000, faculty: 2400, finance: 2400, hr: 5000, it: 2500 },
        { name: 'QTR 2', estates: 3000, faculty: 1398, finance: 2210, hr: 1000, it: 6540 },
        { name: 'QTR 3', estates: 1000, faculty: 9800, finance: 2290, hr: 2000, it: 2500 },
        { name: 'QTR 4', estates: 500, faculty: 3908, finance: 2000, hr: 3000, it: 1500 }
    ];

    const [visibleLines, setVisibleLines] = useState({
        estates: true,
        faculty: true,
        finance: true,
        hr: true,
        it: true,
    });

    const handleLegendClick = (key) => {
        setVisibleLines((prev) => ({
            ...prev,
            [key]: !prev[key],
        }));
    };

    const legendItems = [
        { key: 'estates', label: 'Estates', color: '#00C49F' },
        { key: 'faculty', label: 'Faculty', color: '#8884d8' },
        { key: 'finance', label: 'Finance', color: '#82ca9d' },
        { key: 'hr', label: 'HR', color: '#FFBB28' },
        { key: 'it', label: 'IT', color: '#FF8042' },
    ];

    const row1 = [
        { label: "Approved Budget", value: "£56.59M" },
        { label: "Actual Cost", value: "£15.89M" },
        { label: "Estimate to Complete", value: "£17.41M" },
    ];

    const row2 = [
        { label: "Estimate at Completion", value: "£47.78M" },
        { label: "Variance", value: "£8.81M" },
    ];

    const headerStyle = {
        backgroundColor: "#426ccdff",
        color: "#fff",
        fontSize: "13px",
        fontWeight: "600",
        textAlign: "center",
    };

    const valueStyle = {
        backgroundColor: "#208920ff",
        color: "#ffffffff",
        fontSize: "16px",
        fontWeight: "bold",
        textAlign: "center",
    };

    return (
        <div className="row">
            <div className="col-md-6">
                <div
                    className="card"
                    style={{
                        height: '250px',
                        backgroundColor: '#fff',
                        border: '1px solid #ddd',
                        borderRadius: '12px',
                        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                    }}
                >
                    <h6 className="font-weight-bold text-center mt-2 mb-2 text-muted">
                        Project Budget by Funding Entity
                    </h6>

                    {/* Custom Legend */}

                    <div style={{ width: '100%', height: '180px' }}>
                        <ResponsiveContainer width="95%" height="100%">
                            <LineChart
                                data={data}
                                margin={{ top: 10, right: 0, left: 0, bottom: 0 }}
                            >
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="name" style={{ fontSize: "10px" }} />
                                <YAxis style={{ fontSize: "10px" }} />
                                <Tooltip contentStyle={{ fontSize: "10px" }} itemStyle={{ fontSize: "10px" }} />

                                {visibleLines.estates && (
                                    <Line type="monotone" dataKey="estates" stroke="#00C49F" dot={false} />
                                )}
                                {visibleLines.faculty && (
                                    <Line type="monotone" dataKey="faculty" stroke="#8884d8" dot={false} />
                                )}
                                {visibleLines.finance && (
                                    <Line type="monotone" dataKey="finance" stroke="#82ca9d" dot={false} />
                                )}
                                {visibleLines.hr && (
                                    <Line type="monotone" dataKey="hr" stroke="#FFBB28" dot={false} />
                                )}
                                {visibleLines.it && (
                                    <Line type="monotone" dataKey="it" stroke="#FF8042" dot={false} />
                                )}
                            </LineChart>
                        </ResponsiveContainer>

                        <div style={{ display: 'flex', justifyContent: 'center', gap: '1rem', fontSize: '12px' }}>
                            {legendItems.map(({ key, label, color }) => (
                                <span
                                    key={key}
                                    onClick={() => handleLegendClick(key)}
                                    style={{
                                        cursor: 'pointer',
                                        color: visibleLines[key] ? color : '#ccc',
                                        textDecoration: visibleLines[key] ? 'none' : 'line-through',
                                        fontWeight: visibleLines[key] ? 'bold' : 'normal',
                                    }}
                                >
                                    ● {label}
                                </span>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

            <div className="col-md-6">
                <div
                    className="card h-100"
                    style={{
                        height: "auto",
                        backgroundColor: "#fff",
                        border: "1px solid #ddd",
                        borderRadius: "12px",
                        boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
                        padding: "15px",
                    }}
                >
                    <div style={{ marginBottom: "2rem" }}>
                        <div
                            style={{
                                display: "grid",
                                gridTemplateColumns: "repeat(3, 1fr)",
                                borderTopLeftRadius: "12px",
                                borderTopRightRadius: "12px",
                                overflow: "hidden",
                                ...headerStyle,
                            }}
                        >
                            {row1.map((item) => (
                                <div
                                    key={item.label}
                                    style={{
                                        padding: "8px",
                                        borderRight: "1px solid #2f4ca0",
                                    }}
                                >
                                    {item.label}
                                </div>
                            ))}
                        </div>
                        <div
                            style={{
                                display: "grid",
                                gridTemplateColumns: "repeat(3, 1fr)",
                                borderBottomLeftRadius: "12px",
                                borderBottomRightRadius: "12px",
                                overflow: "hidden",
                                ...valueStyle,
                            }}
                        >
                            {row1.map((item) => (
                                <div
                                    key={item.value}
                                    style={{
                                        padding: "10px",
                                        borderRight: "1px solid #004d00",
                                    }}
                                >
                                    {item.value}
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Row 2 */}
                    <div>
                        {/* Header Row */}
                        <div
                            style={{
                                display: "grid",
                                gridTemplateColumns: "repeat(2, 1fr)",
                                borderTopLeftRadius: "12px",
                                borderTopRightRadius: "12px",
                                overflow: "hidden",
                                ...headerStyle,
                            }}
                        >
                            {row2.map((item) => (
                                <div
                                    key={item.label}
                                    style={{
                                        padding: "8px",
                                        borderRight: "1px solid #2f4ca0",
                                    }}
                                >
                                    {item.label}
                                </div>
                            ))}
                        </div>

                        {/* Value Row */}
                        <div
                            style={{
                                display: "grid",
                                gridTemplateColumns: "repeat(2, 1fr)",
                                borderBottomLeftRadius: "12px",
                                borderBottomRightRadius: "12px",
                                overflow: "hidden",
                                ...valueStyle,
                            }}
                        >
                            {row2.map((item) => (
                                <div
                                    key={item.value}
                                    style={{
                                        padding: "10px",
                                        borderRight: "1px solid #004d00",
                                    }}
                                >
                                    {item.value}
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ThirdComponent;
