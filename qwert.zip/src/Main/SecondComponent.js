import { useState } from "react";
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    Tooltip,
    ResponsiveContainer,
    Pie,
    PieChart,
    Cell,
} from "recharts";

const SecondComponent = () => {
    const [visibleBars, setVisibleBars] = useState({
        green: true,
        amber: true,
        red: true,
    });

    const handleLegendClick = (key) => {
        setVisibleBars((prev) => ({
            ...prev,
            [key]: !prev[key],
        }));
    };

    const projectBudgetData = [
        { name: "IT", green: 27.9, red: 23.3 },
        { name: "Faculty", green: 13.8, amber: 2.8 },
        { name: "HR", green: 4.0 },
        { name: "Estates", red: 3.3 },
        { name: "Finance", red: 2.5, green: 1.5 },
    ];

    const legendItems = [
        { key: 'green', label: 'Green', color: '#00C49F' },
        { key: 'amber', label: 'Amber', color: '#FFBB28' },
        { key: 'red', label: 'Red', color: '#FF4D4F' },
    ];

    const portfolioBalanceData = [
        { name: "Cost Avoidance", value: 10.2 },
        { name: "Cost Reduction", value: 12.2 },
        { name: "Growth", value: 21.9 },
        { name: "Sustaining", value: 24.9 },
        { name: "Maintaining", value: 28.3 },
    ];
    const pieColors = ["#8a2be2", "#9932cc", "#ff8c00", "#1e90ff", "#4169e1"];

    const approvedBudgetData = [
        { quarter: "Q1", value: 13.5 },
        { quarter: "Q2", value: 14.9 },
        { quarter: "Q3", value: 19.4 },
        { quarter: "Q4", value: 27.9 },
        { quarter: "Total", value: 57.7 },
    ];


    return (
        <div className="row">
            <div className="col-md-4">
                <div
                    className="card"
                    style={{
                        height: "250px",
                        backgroundColor: "#fff",
                        border: "1px solid #ddd",
                    }}
                >
                    <h6 className="font-weight-bold text-center mt-2 mb-2 text-muted">
                        Project Budget by Funding Entity
                    </h6>
                    <div style={{ width: "100%", height: "180px" }}>
                        <ResponsiveContainer width="100%" height={180}>
                            <BarChart
                                data={projectBudgetData}
                                layout="vertical"
                                margin={{ top: 10, right: 30, left: 20, bottom: -10 }}
                                barCategoryGap="10%"
                            >
                                <XAxis
                                    axisLine={false}
                                    type="number"
                                    tickFormatter={(v) => `${v}M`}
                                    style={{ fontSize: "10px" }}
                                />
                                <YAxis
                                    axisLine={false}
                                    type="category"
                                    dataKey="name"
                                    style={{ fontSize: "10px" }}
                                />
                                <Tooltip
                                    contentStyle={{ fontSize: "10px" }}
                                    itemStyle={{ fontSize: "10px" }}
                                    cursor={{ fill: "transparent" }}
                                />
                                {visibleBars.green && (
                                    <Bar dataKey="green" stackId="a" fill="#00C49F" barSize={21} />
                                )}
                                {visibleBars.amber && (
                                    <Bar dataKey="amber" stackId="a" fill="#FFBB28" barSize={21} />
                                )}
                                {visibleBars.red && (
                                    <Bar dataKey="red" stackId="a" fill="#FF4D4F" barSize={21} />
                                )}
                            </BarChart>
                        </ResponsiveContainer>
                        <div style={{ display: 'flex', justifyContent: 'center', gap: '1rem', fontSize: '12px' }}>
                            {legendItems.map(({ key, label, color }) => (
                                <span
                                    key={key}
                                    onClick={() => handleLegendClick(key)}
                                    style={{
                                        cursor: 'pointer',
                                        color: visibleBars[key] ? color : '#ccc',
                                        textDecoration: visibleBars[key] ? 'none' : 'line-through',
                                        fontWeight: visibleBars[key] ? 'bold' : 'normal',
                                    }}
                                >
                                    ● {label}
                                </span>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

            <div className="col-md-4">
                <div
                    className="card "
                    style={{
                        height: "250px",
                        backgroundColor: "#fff",
                        border: "1px solid #ddd",
                    }}
                >
                    <h6 className="font-weight-bold text-center mt-2 mb-3 text-muted">
                        Portfolio Balance
                    </h6>
                    <div style={{ width: "100%", height: "100%" }}>
                        <ResponsiveContainer width="100%" height={180}>
                            <PieChart>
                                <Pie
                                    data={portfolioBalanceData}
                                    dataKey="value"
                                    nameKey="name"
                                    outerRadius={70}
                                    labelLine={true} // shows the line with the name
                                    label={(entry) => entry.value} // displays value inside the slice
                                >
                                    {portfolioBalanceData.map((entry, index) => (
                                        <Cell
                                            key={`cell-${index}`}
                                            fill={pieColors[index % pieColors.length]}
                                        />
                                    ))}
                                </Pie>
                                <Tooltip />
                            </PieChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>

            <div className="col-md-4">
                <div
                    className="card "
                    style={{
                        height: "250px",
                        backgroundColor: "#fff",
                        border: "1px solid #ddd",
                    }}
                >
                    <h6 className="font-weight-bold text-center mt-2 mb-3 text-muted">
                        Approved Budget by Quarter
                    </h6>
                    <div style={{ width: "100%", height: "100%" }}>
                        <ResponsiveContainer width="100%" height={180}>
                            <BarChart
                                data={approvedBudgetData}
                                margin={{ top: 10, right: 30, left: 20, bottom: -10 }}
                                barCategoryGap="10%"
                            >
                                <XAxis
                                    axisLine={false}
                                    dataKey="quarter"
                                    style={{ fontSize: "10px" }}
                                />
                                <YAxis
                                    axisLine={false}
                                    style={{ fontSize: "10px" }}
                                    tickFormatter={(v) => `£${v}M`}
                                />
                                <Tooltip
                                    contentStyle={{ fontSize: "10px" }}
                                    itemStyle={{ fontSize: "10px" }}
                                    formatter={(v) => `£${v}M`}
                                    cursor={{ fill: "transparent" }}
                                />
                                <Bar dataKey="value">
                                    {approvedBudgetData.map((entry, index) => (
                                        <Cell
                                            key={`cell-${index}`}
                                            fill={index === 4 ? "#1890FF" : "#00C49F"}
                                        />
                                    ))}
                                </Bar>
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SecondComponent;
