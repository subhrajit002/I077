import React from 'react'

const FirstComponent = () => {
    return (
        <div className="row">

            <div className="col-md-3">
                <div
                    className="card p-3 h-100"
                    style={{ backgroundColor: "#fff", border: "1px solid #ddd" }}
                >
                    <div className="card-body p-0">
                        <div className="row g-2">
                            <div className="col-6">
                                <button className="btn btn-outline-primary w-100">Estates</button>
                            </div>
                            <div className="col-6">
                                <button className="btn btn-outline-primary w-100">Faculty</button>
                            </div>
                            <div className="col-6">
                                <button className="btn mt-2 btn-outline-primary w-100">Finance</button>
                            </div>
                            <div className="col-6">
                                <button className="btn mt-2 btn-outline-primary w-100">HR</button>
                            </div>
                            <div className="col-6">
                                <button className="btn mt-2 btn-outline-primary w-100">IT</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="col-md-3">
                <div
                    className="card h-100 p-3"
                    style={{
                        backgroundColor: "#fff",
                        border: "1px solid #ddd",
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center",
                        alignItems: "center",
                        textAlign: "center",
                    }}
                >
                    <h3 style={{ fontSize: "3.5rem", color: "#1E3A8A", fontWeight: "bold", margin: 0 }}>4.04</h3>
                    <h6 className="text-muted mb-0" style={{ fontSize: "1.25rem", marginTop: "12px" }}>Portfolio Risk Score</h6>
                </div>
            </div>


            {/* Actual Cost */}
            <div className="col-md-3">
                <div
                    className="card h-100 p-3"
                    style={{
                        backgroundColor: "#fff",
                        border: "1px solid #ddd",
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center",
                        alignItems: "center",
                        textAlign: "center",
                    }}
                >
                    <h3 style={{ fontSize: "3.5rem", color: "#1E3A8A", fontWeight: "bold", margin: 0 }}>4.47</h3>
                    <h6 className="text-muted mb-0" style={{ fontSize: "1.25rem", marginTop: "12px" }}>Portfolio Risk Last Quarter</h6>
                </div>
            </div>

            {/* Table Section */}
            <div className="col-md-3">
                <div
                    className="card"
                    style={{ backgroundColor: "#fff", border: "1px solid #ddd" }}
                >
                    <div className="card-body p-2 d-flex flex-column" style={{ height: "100%" }}>
                        {/* Table at the top */}
                        <table
                            className="table table-bordered table-sm mb-0"
                            style={{ fontSize: "0.75rem", marginBottom: 0 }}
                        >
                            <thead>
                                <tr>
                                    <th scope="col">Status</th>
                                    <th scope="col">Project</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Demand</td>
                                    <td>14</td>
                                </tr>
                                <tr>
                                    <td>Active</td>
                                    <td>35</td>
                                </tr>
                                <tr>
                                    <td>Total</td>
                                    <td>49</td>
                                </tr>
                            </tbody>
                        </table>

                        {/* Buttons at the bottom */}
                        <div className="d-flex flex-column gap-2 mt-auto">
                            <button disabled className="btn mt-1 btn-danger btn-sm">
                                RED 45
                            </button>
                            <button disabled className="btn mt-1 btn-warning btn-sm">
                                Amber 6
                            </button>
                            <button disabled className="btn mt-1 btn-success btn-sm">
                                Green 31
                            </button>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    )
}

export default FirstComponent
