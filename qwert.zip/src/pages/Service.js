import React from "react";
import FirstComponent from "../Main/FirstComponent";
import SecondComponent from "../Main/SecondComponent";
import ThirdComponent from "../Main/ThirdComponent";
import FourthComponent from "../Main/FourthComponent";

const Services = () => {
    return (
        <div className="container-fluid bg-white p-3">
            <FirstComponent />
            <div className="mt-3">
                <SecondComponent />
            </div>
            <div className="mt-3">
                <ThirdComponent />
            </div>
            <div className="mt-3">
                <FourthComponent />
            </div>
        </div>
    );
};

export default Services;
