import React from 'react'
import ProjectPortfolioDashboard from '../components/Dashboard2'

const About = () => {
    return (
        <div>
            <ProjectPortfolioDashboard />
        </div>
    )
}

export default About
