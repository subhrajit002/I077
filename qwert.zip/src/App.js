import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import RightNavbar from "./components/RightNavbar";
import Services from "./pages/Service";
import About from "./pages/About";

function App() {
  return (
    <Router>
      <Header />
      <RightNavbar />
      <div
        className="content text-center"
        style={{
          paddingTop: "80px",
          paddingLeft: "240px",
        }}
      >
        <Routes>
          <Route path="/services" element={<Services />} />
          <Route path="/about" element={<About />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
