"use client"

import { useState } from "react"

import "./App.css"
import CreateTicketOffcanvas from "./CreateTicketOffcanvas"
import Header from "./Header"
import TicketTable from "./TicketTable"
import Sidebar from "./Sidebar"
import LoadingModal from "./LoadingModal"

function App() {
  const [showOffcanvas, setShowOffcanvas] = useState(false)
  const [showLoading, setShowLoading] = useState(false)
  const [tickets, setTickets] = useState([
    {
      id: "#TC-192",
      subject: "Help, I order wrong product...",
      priority: "high",
      type: "incident",
      client: "Santi Carloza",
      date: "07/11/2023, 06:25AM",
    },
    {
      id: "#TC-191",
      subject: "My Suggestion for this product",
      priority: "low",
      type: "suggestion",
      client: "Fast Response",
      date: "06/11/2023, 11:47PM",
    },
    {
      id: "#TC-190",
      subject: "Can i use the TV in bathroom?",
      priority: "medium",
      type: "question",
      client: "Arlene McCoy",
      date: "06/11/2023, 05:31AM",
    },
    {
      id: "#TC-189",
      subject: "Your offline store is dirty",
      priority: "low",
      type: "suggestion",
      client: "Darlene Robertson",
      date: "05/11/2023, 09:05PM",
    },
    {
      id: "#TC-188",
      subject: "Can i get the free battery for ...",
      priority: "low",
      type: "question",
      client: "Jerome Bell",
      date: "04/11/2023, 02:30PM",
    },
    {
      id: "#TC-187",
      subject: "I can't move this stroller, it's s...",
      priority: "medium",
      type: "problem",
      client: "Cody Fisher",
      date: "04/11/2023, 11:28AM",
    },
    {
      id: "#TC-186",
      subject: "Help! My package is lost",
      priority: "low",
      type: "incident",
      client: "Courtney Henry",
      date: "03/11/2023, 10:10AM",
    },
    {
      id: "#TC-185",
      subject: "This remote tv is broken, can ...",
      priority: "medium",
      type: "problem",
      client: "Leslie Alexander",
      date: "31/10/2023, 04:13PM",
    },
    {
      id: "#TC-184",
      subject: "Stroller wheel stuck, i wan't ta...",
      priority: "medium",
      type: "problem",
      client: "Robert Fox",
      date: "30/10/2023, 07:46PM",
    },
    {
      id: "#TC-183",
      subject: "We missing the wheel of the ...",
      priority: "high",
      type: "incident",
      client: "Ronald Richards",
      date: "29/10/2023, 03:07AM",
    },
    {
      id: "#TC-182",
      subject: "Black screen on this monitor",
      priority: "high",
      type: "incident",
      client: "Floyd Miles",
      date: "27/10/2023, 12:00PM",
    },
    {
      id: "#TC-181",
      subject: "How to install this? can you h...",
      priority: "medium",
      type: "question",
      client: "Esther Howard",
      date: "26/10/2023, 01:04PM",
    },
    {
      id: "#TC-180",
      subject: "Stroller wheel stuck, i wan't ta...",
      priority: "low",
      type: "incident",
      client: "Cameron Williamson",
      date: "26/10/2023, 10:33AM",
    },
    {
      id: "#TC-179",
      subject: "Help, I order wrong product...",
      priority: "high",
      type: "incident",
      client: "Marvin McKinney",
      date: "23/10/2023, 04:38AM",
    },
    {
      id: "#TC-178",
      subject: "Black screen on this monitor",
      priority: "high",
      type: "problem",
      client: "Sarah Johnson",
      date: "22/10/2023, 10:07PM",
    },
    {
      id: "#TC-177",
      subject: "Help, I order wrong product...",
      priority: "low",
      type: "incident",
      client: "David Smith",
      date: "21/10/2023, 11:2 PM",
    },
    {
      id: "#TC-176",
      subject: "We missing the wheel of the ...",
      priority: "medium",
      type: "incident",
      client: "Emily Davis",
      date: "18/10/2023, 06:14PM",
    },
    {
      id: "#TC-175",
      subject: "Help! My package is lost",
      priority: "high",
      type: "problem",
      client: "Annette Black",
      date: "18/10/2023, 12:20AM",
    },
  ])

  const handleAddTicket = () => {
    setShowOffcanvas(true)
  }

  const handleCloseOffcanvas = () => {
    setShowOffcanvas(false)
  }

  const handleSubmitTicket = async (ticketData) => {
    setShowLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Generate new ticket ID
    const newId = `#TC-${193 + tickets.length}`
    const currentDate = new Date()
      .toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        hour12: true,
      })
      .replace(",", ",")

    const newTicket = {
      id: newId,
      subject: ticketData.ticketName,
      priority: ticketData.priority,
      type: ticketData.ticketType,
      client: ticketData.requestor,
      date: currentDate,
    }

    // Add to beginning of tickets array
    setTickets((prevTickets) => [newTicket, ...prevTickets])

    setShowLoading(false)
    setShowOffcanvas(false)
  }

  return (
    <div className="app-container">
      <Sidebar />
      <div className="main-content">
        <Header onAddTicket={handleAddTicket} />
        <TicketTable tickets={tickets} />
      </div>

      <CreateTicketOffcanvas show={showOffcanvas} onClose={handleCloseOffcanvas} onSubmit={handleSubmitTicket} />

      <LoadingModal show={showLoading} />
    </div>
  )
}

export default App
