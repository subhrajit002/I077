const TicketTable = ({ tickets }) => {
    const getPriorityClass = (priority) => {
        return `priority-badge priority-${priority}`
    }

    const getTypeClass = (type) => {
        return `type-icon type-${type}`
    }

    const getTypeIcon = (type) => {
        const icons = {
            incident: "fas fa-exclamation-triangle",
            suggestion: "fas fa-lightbulb",
            question: "fas fa-question-circle",
            problem: "fas fa-bug",
        }
        return icons[type] || "fas fa-circle"
    }

    const getClientInitials = (name) => {
        return name
            .split(" ")
            .map((n) => n[0])
            .join("")
            .toUpperCase()
    }

    return (
        <div className="ticket-table-container">
            <table className="ticket-table">
                <thead>
                    <tr>
                        <th className="checkbox-col">
                            <input type="checkbox" />
                        </th>
                        <th>
                            Ticket ID <i className="fas fa-sort"></i>
                        </th>
                        <th>Subject</th>
                        <th>
                            Priority <i className="fas fa-sort"></i>
                        </th>
                        <th>
                            Type <i className="fas fa-sort"></i>
                        </th>
                        <th>
                            Client <i className="fas fa-sort"></i>
                        </th>
                        <th>
                            Request Date <i className="fas fa-sort"></i>
                        </th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    {tickets.map((ticket, index) => (
                        <tr key={index}>
                            <td className="checkbox-col">
                                <input type="checkbox" />
                            </td>
                            <td>
                                <span className="ticket-id">{ticket.id}</span>
                            </td>
                            <td>
                                <span className="ticket-subject">{ticket.subject}</span>
                            </td>
                            <td>
                                <span className={getPriorityClass(ticket.priority)}>{ticket.priority}</span>
                            </td>
                            <td>
                                <div className="type-badge">
                                    <div className={getTypeClass(ticket.type)}>
                                        <i className={getTypeIcon(ticket.type)}></i>
                                    </div>
                                    {ticket.type.charAt(0).toUpperCase() + ticket.type.slice(1)}
                                </div>
                            </td>
                            <td>
                                <div className="client-info">
                                    <div className="client-avatar">{getClientInitials(ticket.client)}</div>
                                    <span className="client-name">{ticket.client}</span>
                                </div>
                            </td>
                            <td>
                                <span className="request-date">{ticket.date}</span>
                            </td>
                            <td>
                                <button className="actions-btn">
                                    <i className="fas fa-ellipsis-h"></i>
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    )
}

export default TicketTable
