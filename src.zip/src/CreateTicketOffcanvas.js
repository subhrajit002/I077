"use client"

import { useState } from "react"
import MessageOffcanvas from "./MessageOffcanvas"

const CreateTicketOffcanvas = ({ show, onClose, onSubmit }) => {
    const [isFullscreen, setIsFullscreen] = useState(false)
    const [showMessagePanel, setShowMessagePanel] = useState(false)

    const [formData, setFormData] = useState({
        ticketName: "",
        priority: "medium",
        ticketType: "incident",
        requestor: "Martin Ødegaard",
        assignee: "Fikri Studio",
        tags: [],
        followers: [],
        message: "",
    })

    const handleInputChange = (field, value) => {
        setFormData((prev) => ({
            ...prev,
            [field]: value,
        }))
    }

    const handleSubmit = (e) => {
        e.preventDefault()
        onSubmit(formData)
        setFormData({
            ticketName: "",
            priority: "medium",
            ticketType: "incident",
            requestor: "Martin Ødegaard",
            assignee: "Fikri Studio",
            tags: [],
            followers: [],
            message: "",
        })
        setIsFullscreen(false)
    }

    const handleClose = () => {
        setIsFullscreen(false)
        onClose()
    }

    if (!show) return null

    return (
        <>
            <div className="offcanvas-backdrop" onClick={handleClose}></div>

            {/* Main Ticket Offcanvas */}
            <div
                className={`create-ticket-offcanvas ${isFullscreen ? "fullscreen" : ""}`}
                style={{ right: showMessagePanel ? "400px" : "0" }}
            >
                <div className="offcanvas-header">
                    <div className="offcanvas-title">
                        <i
                            className="fas fa-ticket-alt"
                            style={{ color: "#28a745", marginRight: "8px" }}
                        ></i>
                        Create New Ticket
                    </div>
                    <div className="offcanvas-controls">
                        {/* Open Message Panel Button */}
                        <button
                            className="control-btn"
                            onClick={() => setShowMessagePanel(true)}
                            title="Open Message Panel"
                        >
                            <i className="fas fa-envelope"></i>
                        </button>

                        {/* Fullscreen toggle */}
                        <button
                            className="control-btn"
                            onClick={() => setIsFullscreen(!isFullscreen)}
                            title={isFullscreen ? "Exit Fullscreen" : "Fullscreen"}
                        >
                            <i className={`fas ${isFullscreen ? "fa-compress" : "fa-expand"}`}></i>
                        </button>

                        {/* Close main panel */}
                        <button
                            className="control-btn"
                            onClick={handleClose}
                            title="Close"
                        >
                            <i className="fas fa-times"></i>
                        </button>
                    </div>
                </div>

                <form onSubmit={handleSubmit} className="offcanvas-content">
                    <div className={`form-layout ${isFullscreen ? "split-layout" : ""}`}>
                        {/* Left side: fields */}
                        <div className="form-fields">
                            <div className="form-group">
                                <label>Ticket Name</label>
                                <input
                                    type="text"
                                    className="form-input"
                                    placeholder="My Suggestion for this product"
                                    value={formData.ticketName}
                                    onChange={(e) =>
                                        handleInputChange("ticketName", e.target.value)
                                    }
                                    required
                                />
                            </div>

                            <div className="form-group">
                                <label>Priority</label>
                                <div className="priority-options">
                                    <label className="priority-option">
                                        <input
                                            type="radio"
                                            name="priority"
                                            value="low"
                                            checked={formData.priority === "low"}
                                            onChange={(e) =>
                                                handleInputChange("priority", e.target.value)
                                            }
                                        />
                                        <span className="priority-dot low"></span>
                                        Low
                                    </label>
                                    <label className="priority-option">
                                        <input
                                            type="radio"
                                            name="priority"
                                            value="medium"
                                            checked={formData.priority === "medium"}
                                            onChange={(e) =>
                                                handleInputChange("priority", e.target.value)
                                            }
                                        />
                                        <span className="priority-dot medium"></span>
                                        Medium
                                    </label>
                                    <label className="priority-option">
                                        <input
                                            type="radio"
                                            name="priority"
                                            value="high"
                                            checked={formData.priority === "high"}
                                            onChange={(e) =>
                                                handleInputChange("priority", e.target.value)
                                            }
                                        />
                                        <span className="priority-dot high"></span>
                                        High
                                    </label>
                                </div>
                            </div>

                            <div className="form-group">
                                <label>Ticket Type</label>
                                <select
                                    className="form-select"
                                    value={formData.ticketType}
                                    onChange={(e) =>
                                        handleInputChange("ticketType", e.target.value)
                                    }
                                >
                                    <option value="incident">Incident</option>
                                    <option value="question">Question</option>
                                    <option value="problem">Problem</option>
                                    <option value="suggestion">Suggestion</option>
                                </select>
                            </div>

                            <div className="form-row">
                                <div className="form-group">
                                    <label>Requestor</label>
                                    <select
                                        className="form-select"
                                        value={formData.requestor}
                                        onChange={(e) =>
                                            handleInputChange("requestor", e.target.value)
                                        }
                                    >
                                        <option value="Martin Ødegaard">Martin Ødegaard</option>
                                        <option value="Santi Carloza">Santi Carloza</option>
                                        <option value="Fast Response">Fast Response</option>
                                    </select>
                                </div>

                                <div className="form-group">
                                    <label>Assignee</label>
                                    <select
                                        className="form-select"
                                        value={formData.assignee}
                                        onChange={(e) =>
                                            handleInputChange("assignee", e.target.value)
                                        }
                                    >
                                        <option value="Fikri Studio">Fikri Studio</option>
                                        <option value="Support Team">Support Team</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        {/* Right side: message when fullscreen */}
                        {isFullscreen ? (
                            <div className="message-section">
                                <div className="form-group">
                                    <label>Message</label>
                                    <div className="message-from">
                                        <span>From</span>
                                        <select className="form-select">
                                            <option>Fikri Studio Support</option>
                                        </select>
                                    </div>
                                    <textarea
                                        className="form-textarea"
                                        placeholder="Comment or Type '/' For commands"
                                        value={formData.message}
                                        onChange={(e) =>
                                            handleInputChange("message", e.target.value)
                                        }
                                    />
                                </div>
                            </div>
                        ) : (
                            <div className="form-group" style={{ padding: "0 20px" }}>
                                <label>Message</label>
                                <textarea
                                    className="form-textarea"
                                    placeholder="Comment or Type '/' For commands"
                                    value={formData.message}
                                    onChange={(e) =>
                                        handleInputChange("message", e.target.value)
                                    }
                                />
                            </div>
                        )}
                    </div>

                    <div className="offcanvas-footer">
                        <button
                            type="button"
                            className="btn-cancel"
                            onClick={handleClose}
                        >
                            Cancel
                        </button>
                        <div className="submit-group">
                            <button type="submit" className="btn-submit">
                                Submit as New
                            </button>
                            <button type="button" className="btn-dropdown">
                                <i className="fas fa-chevron-down"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            {/* Message Offcanvas */}
            <MessageOffcanvas
                show={showMessagePanel}
                onClose={() => setShowMessagePanel(false)}
                formData={formData}
                setFormData={setFormData}
            />
        </>
    )
}

export default CreateTicketOffcanvas
