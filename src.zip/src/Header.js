"use client"

const Header = ({ onAddTicket }) => {
  return (
    <div className="header">
      <div className="header-top">
        <h1 className="header-title">Ticket</h1>
        <div className="header-actions">
          <button className="btn-focus">
            <i className="fas fa-crosshairs"></i> Focus Mode
          </button>
          <button className="btn-add-ticket" onClick={onAddTicket}>
            <i className="fas fa-plus"></i> Add Ticket
          </button>
        </div>
      </div>

      <div className="header-filters">
        <div className="search-box">
          <i className="fas fa-search"></i>
          <input type="text" placeholder="Search" />
          <span style={{ fontSize: "12px", color: "#6c757d", marginLeft: "8px" }}>⌘ K</span>
        </div>

        <button className="filter-btn">
          <i className="fas fa-tag"></i>
          Type
        </button>

        <button className="filter-btn">
          <i className="fas fa-external-link-alt"></i>
          Source
        </button>

        <button className="filter-btn">
          <i className="fas fa-exclamation-circle"></i>
          Priority
        </button>

        <button className="filter-btn">
          <i className="fas fa-calendar"></i>
          Date Added
        </button>

        <button className="filter-btn">
          <i className="fas fa-filter"></i>
          Ticket Filters
        </button>
      </div>
    </div>
  )
}

export default Header
