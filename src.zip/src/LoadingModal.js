const LoadingModal = ({ show }) => {
  if (!show) return null

  return (
    <div className="loading-modal-backdrop">
      <div className="loading-modal">
        <div className="loading-content">
          <div className="loading-icon">
            <i className="fas fa-spinner fa-spin"></i>
          </div>
          <h3>Submitting Ticket</h3>
          <p>Preparing New Ticket</p>
          <button className="btn-cancel-loading">Cancel</button>
        </div>
      </div>
    </div>
  )
}

export default LoadingModal
