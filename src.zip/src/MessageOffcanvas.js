"use client"

const MessageOffcanvas = ({ show, onClose, formData, setFormData }) => {
    if (!show) return null

    return (
        <div className="message-offcanvas">
            <div className="msg-header">
                <span>
                    <i className="fas fa-envelope" style={{ marginRight: "6px", color: "#007bff" }}></i>
                    Message
                </span>
                <button className="msg-close-btn" onClick={onClose}>
                    <i className="fas fa-times"></i>
                </button>
            </div>

            <div className="msg-body">
                <div className="form-group">
                    <label>From</label>
                    <select className="form-select" defaultValue="Fikri Studio Support">
                        <option>Fikri Studio Support</option>
                        <option>Customer Care</option>
                    </select>
                </div>

                <div className="form-group">
                    <label>Message</label>
                    <textarea
                        className="form-textarea"
                        placeholder="Comment or Type '/' For commands"
                        value={formData.message}
                        onChange={(e) =>
                            setFormData((prev) => ({ ...prev, message: e.target.value }))
                        }
                    />
                </div>
            </div>
        </div>
    )
}

export default MessageOffcanvas
